// ============================================================
//  mode_2.ino  —  Duel
// all serial prints used in here are for debugging purpose on simuleide
// ============================================================

#include "hardware.h"
#include "config2.h"

// variables from the main file
extern int p1Score;
extern int p2Score;
extern bool willExit;

void playmode2() {
  int difficulty_level = DIFFICULTY_LEVEL;
  int rounds = 0;
  int LED_Sequence[20];

  Serial.println(F("=== DUEL MODE START ==="));

  while (rounds < NUM_OF_ITERATIONS) {
    if (willExit) return;

    for (int i = 0; i < difficulty_level; i++) {
       LED_Sequence[i] = turnOnRandomLED();
      _delay_ms(BlinkTime);
      turnOffAll();
      _delay_ms(400);
    }

    // Print sequence to Serial for debugging
    Serial.print(F("Round "));
    Serial.print(rounds + 1);
    Serial.print(F("  Sequence: "));
    for (int i = 0; i < difficulty_level; i++) {
      Serial.print(LED_Sequence[i]);
      Serial.print(' ');
    }
    Serial.println();

    // ── make sure rounds start from zero (initial state) ───────────────────────────────────────────────────────
    int i1 = 0, i2 = 0;  // checks where the player reached where if he gets the first led right i1++ or i2 ++
    bool p1Eliminated = false;
    bool p2Eliminated = false;
    bool p1Finished = false;
    bool p2Finished = false;
    unsigned long p1FinishTime = 0;
    unsigned long p2FinishTime = 0;
    unsigned long startTime = millis();


    bool released1 = true;
    bool released2 = true;

    Serial.println(F("--- Input phase started ---"));

    // ── Concurrent input loop ─────────────────────────────────────────────────
    while (true) {

      if (millis() - startTime >= ROUND_TIMEOUT) {
        Serial.println(F("TIMEOUT"));
        break;
      }

      unsigned long now = millis();
      int btn1 = getButtonPressed();
      int btn2 = getPlayer2Button();

      // Update release flags
      if (btn1 == -1) released1 = true;
      if (btn2 == -1) released2 = true;

      if (btn1 != -1) {
        Serial.print(F("P1 pressed: "));
        Serial.print(btn1);
        Serial.print(F(" Expects: "));
        Serial.print(LED_Sequence[i1]);
        Serial.print(F(" i1="));
        Serial.println(i1);
      }
      if (btn2 != -1) {
        Serial.print(F("P2 pressed: "));
        Serial.print(btn2);
        Serial.print(F(" | Expects: "));
        Serial.print(LED_Sequence[i2]);
        Serial.print(F(" | i2="));
        Serial.println(i2);
      }

      // ── Player 1:  (checks if btn is released first) ──────
      if (!p1Eliminated && !p1Finished && btn1 != -1 && released1) {
        released1 = false;  // mark as held until released
        if (btn1 == LED_Sequence[i1]) {
          i1++;
          Serial.print(F("P1 correct! i1="));
          Serial.println(i1);
          if (i1 == difficulty_level) {
            p1Finished = true;
            p1FinishTime = now - startTime;
            Serial.println(F("P1 FINISHED"));
          }
        } else {
          p1Eliminated = true;
          Serial.println(F("P1 WRONG — eliminated"));
        }
      }

      // ── Player 2: (checks if btn is released first) ───────────────────────────────────
      if (!p2Eliminated && !p2Finished && btn2 != -1 && released2) {
        released2 = false;  // mark as held until released
        if (btn2 == LED_Sequence[i2]) {
          i2++;
          Serial.print(F("P2 correct! i2="));
          Serial.println(i2);
          if (i2 == difficulty_level) {
            p2Finished = true;
            p2FinishTime = now - startTime;
            Serial.println(F("P2 FINISHED"));
          }
        } else {
          p2Eliminated = true;
          Serial.println(F("P2 WRONG — eliminated"));
        }
      }

      if (p1Finished || p2Finished) break;
      if (p1Eliminated && p2Eliminated) break;
    }

    // ── Determine round winner ────────────────────────────────────────────────
    const char* result;


    if (p1Finished && p2Finished) {
      if (p1FinishTime < p2FinishTime) {
        p1Score++;
        result = "P1 First! P1+1";
      } else if (p2FinishTime < p1FinishTime) {
        p2Score++;
        result = "P2 First! P2+1";
      } else {
        result = "Dead Tie!";
      }
    } else if (p1Finished) {
      p1Score++;
      result = "P1 Wins Round!";
    } else if (p2Finished) {
      p2Score++;
      result = "P2 Wins Round!";
    } else {
      result = "No Winner!";
    }

    if (p1Finished || p2Finished) {  // increases dificulty level as perviously done in my mode 1
      difficulty_level++;
      Serial.print(F("DIFFICULTY LEVEL IS INCREASED"));
      Serial.println(difficulty_level);
    } else {

      difficulty_level = DIFFICULTY_LEVEL;
      Serial.print(F("DIFFICULTY RESET --- NO WINNERS"));
    }

    Serial.print(F("RESULT: "));
    Serial.println(result);
    Serial.print(F("Scores — P1: "));
    Serial.print(p1Score);
    Serial.print(F("  P2: "));
    Serial.println(p2Score);

    displayRoundResult(result);
    updateScores();
    _delay_ms(1500);

    rounds++;
    displayRoundNumber(rounds);
    _delay_ms(1000);
  }

  Serial.println(F("=== DUEL MODE OVER ==="));
  Serial.print(F("Final — P1: "));
  Serial.print(p1Score);
  Serial.print(F("  P2: "));
  Serial.println(p2Score);
  displayGameOver();
  delay(3000);
  // Returns to loop(), currentState resets to 0 (menu)
}
