// ============================================================
// Button / Keypad Input
// ============================================================
#include <LiquidCrystal_I2C.h>
extern LiquidCrystal_I2C lcd;
#include "hardware.h"
#include "config2.h"
extern bool willExit;

int btns1[] = BTN_ARRAY_ONE;  // player one buttons
int btns2[] = BTN_ARRAY_TWO;  // player two buttons

static bool p1Released = true;  // player one state
static bool p2Released = true;  // player two state

// ── Initialise Player 1 buttons (Port D) (input pull-up) ──────────────────────
void intializeKeypad() {
  for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {
    BTN_DDR &= ~(1 << btns1[i]);  // sets buttons pins as input (pullup)
    BTN_PORT |= (1 << btns1[i]);  // sets pins as 1 (low)
  }
}

// ── Initialise Player 2 buttons (Port B) (input pull-up) ──────────────────────
void intializeKeypad2() {
  for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {
    BTN_2_DDR &= ~(1 << btns2[i]);  // sets buttons pins as input (pullup)
    BTN_2_PORT |= (1 << btns2[i]);  // sets pins as 1 (low)
  }
}

// ── Read Player 1 button ──────────────────────────────────────────────────────
int getButtonPressed() {
  for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {  // checks all buttons for a pressed one
    if ((BTN_PIN & (1 << btns1[i])) == 0) {           //if pin reads 0 (high)
      _delay_ms(DEBOUNCE_TIME);                       // debounce AFTER detecting a press
      if ((BTN_PIN & (1 << btns1[i])) == 0) {         // confirm still pressed
        if (i == 3) {
          unsigned long longPressStart = millis();
          while ((BTN_PIN & (1 << btns1[3])) == 0) {

            if (millis() - longPressStart >= 7000) {

              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("Exiting ....");
              _delay_ms(500);
               
               while((BTN_PIN & (1 << btns1[3])) == 0) { _delay_ms(10); }
              willExit = true;

              return 3;
            }
          }
          return 3;
        }


        return i;  // return button pressed
      }
    }
  }
  p1Released = true;  // release state
  return -1;          // no btn pressed
}

// ── Read Player 2 button ──────────────────────────────────────────────────────
int getPlayer2Button() {
  for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {  // checks all buttons for a pressed one
    if ((BTN_2_PIN & (1 << btns2[i])) == 0) {         // if pin reads 0 (high)
      _delay_ms(DEBOUNCE_TIME);                       // debounce AFTER detecting a press, not before
      if ((BTN_2_PIN & (1 << btns2[i])) == 0) {       // confirm still pressed
        return i;                                     // return button pressed
      }
    }
  }
  p2Released = true;  // release state
  return -1;          // no btn pressed
}
