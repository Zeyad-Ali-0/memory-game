#define NUM_OF_ITERATIONS      5      //Number of rounds 
#define BlinkTime              500    //Time between LEDS' blinking at the beginning

#define ROUND_TIMEOUT          15000  //A round time of 15 secs
#define DEBOUNCE_TIME          30  //Button debounce time of 30 millisecs
#define DIFFICULTY_LEVEL       3      //Defualt difficulty level 
#define NUM_OF_BTNS_PER_PLAYER 4      //Number of buttons for each player
