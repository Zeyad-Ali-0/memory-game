// ============================================================
//  menu.ino
//  Displays the mode-selection menu on the LCD and reads
//  Player 1's button to set the global currentState.
// ============================================================

extern int currentState;

void menuFunction() {
  willExit = false;
  
while (getButtonPressed() != -1) { _delay_ms(10); }
  // shows menu on LCD 
  lcd.setCursor(0, 0);
  lcd.print("1:Solo  2:Duel      ");
  lcd.setCursor(0, 1);
  lcd.print("3:Challenger            ");

  int btn = getButtonPressed();

  if (btn != -1) {
    Serial.print(F(" Button pressed: "));
    Serial.println(btn);

    if (btn == 0) {
      currentState = 1;
      Serial.println(F(" Solo Mode selected "));
    } else if (btn == 1) {
      currentState = 2;
      Serial.println(F(" Duel Mode selected "));
    } else if (btn == 2) {
      currentState = 3;
      Serial.println(F(" Challenger Mode selected "));
    }

    lcd.clear();
    _delay_ms(300);   // delay after clearing
  }
}
