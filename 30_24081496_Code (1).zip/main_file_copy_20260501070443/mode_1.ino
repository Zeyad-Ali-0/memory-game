// ============================================================
//  mode_1.ino  —  Solo
// ============================================================
extern bool willExit;
#include "hardware.h"
#include "config2.h"

// variables from the main file
extern int pass;
extern int fail;
extern long totalTime;
extern int difficulty_level;

void playmode1() {
  randomSeed(millis());
  int LED_Sequance[20];
  int i;

  while (pass + fail < NUM_OF_ITERATIONS) {  // allows for 5 rounds only

    if (willExit) return;

    long start_t = millis();

    // Generate random LED sequence
    for (i = 0; i < difficulty_level; i++) {
      LED_Sequance[i] = turnOnRandomLED();
      _delay_ms(BlinkTime);
      turnOffAll();
      _delay_ms(400);
    }


    // Collect player input
    for (i = 0; i < difficulty_level; i++) {
      int btn = -1;

      // Wait for any previous press to be released first
      while (getButtonPressed() != -1) { _delay_ms(10); }
      _delay_ms(150);
      // then wait for another button to be pressed again
      while (btn == -1) {
        btn = getButtonPressed();
      }
      // Wait for button release before continuing to next step
      while (getButtonPressed() != -1) { _delay_ms(10); }

      // then wait for another button to be pressed again
      if (btn != LED_Sequance[i]) {
        difficulty_level = DIFFICULTY_LEVEL;  // reset difficulty on wrong answer
        fail++;
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Fail: ");
        lcd.print(fail);
        Serial.println(F("FAIL"));
        _delay_ms(2000);
        break;
      }
    }

    if (i == difficulty_level) {
      Serial.println(F("SUCCESS"));
      difficulty_level++;
      pass++;
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Pass: ");
      lcd.print(pass);
      long end_t = millis();
      Serial.println((float)(end_t - start_t) / 1000.0);
      totalTime += end_t - start_t;
    }
  }

  // ── Game summary ─────────────────────────────────────────────────────────
  Serial.println(F("======================"));
  Serial.print(F("Pass : "));
  Serial.println(pass);
  Serial.print(F("Fail : "));
  Serial.println(fail);
  Serial.print(F("Avg Time : "));
  if (pass != 0) {
    Serial.println((float)(totalTime / pass) / 1000.0);

  } else {
    Serial.println(F("NO PASSES"));
  }
  Serial.println(F("Mode 1 Ended"));
  Serial.println(F("======================"));

  loop_LCD_SCREEN_mode1();
  delay(7000);
  // Returns to loop() , currentState resets to 0 (menu)
}
