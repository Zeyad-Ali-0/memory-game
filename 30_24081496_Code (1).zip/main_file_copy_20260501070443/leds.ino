// ============================================================
//  leds.ino  —  LED Control
// ============================================================

#include "hardware.h"
#include "config2.h"

static const int LED_PINS[] = LED_ARRAY;

void initializeLEDs() {
  for (int i = 0; i < NUM_OF_LEDS; i++) {
    LED_DDR  |=  (1 << LED_PINS[i]);            // sets them to output 
    LED_PORT &= ~(1 << LED_PINS[i]);            // sets them as (1) high
  }
}

void turnOffAll() {
  for (int i = 0; i < NUM_OF_LEDS; i++) {
    LED_PORT &= ~(1 << LED_PINS[i]);              // sets all leds to low (0)
  }
}

void turnOnAll() {
  for (int i = 0; i < NUM_OF_LEDS; i++) {
    LED_PORT |= (1 << LED_PINS[i]);              // sets all leds to high (1)
  }
}

int turnOnRandomLED() {
  int l = random(NUM_OF_LEDS);
  turnOffAll();
  LED_PORT |= (1 << LED_PINS[l]);   // the random function is embed in arduino
  return l;
}
