// ============================================================
// Every other .ino file uses `extern` to reference .h files from here to avoid redifinition.
// ============================================================

#include "hardware.h"
#include "config2.h"
#include <Wire.h>
//#include <LiquidCrystal_I2C.h>
#include <LiquidCrystal_I2C.h>
// ── Single LCD instance (I2C, address 0x3E, 20×4) ((for simulide only))
//LiquidCrystal_I2C lcd(0x27, 16, 2);  // for hardware
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ── Global game-state variables ───────────────────────────────────────────────
int currentState = 0;  // 0 = menu, 1 = mode1, 2 = mode2, 3 = mode3
bool willExit = false;

// Mode 1 (Solo) =============================
int pass = 0;
int fail = 0;
long totalTime = 0;
int difficulty_level = DIFFICULTY_LEVEL;
// ====================================

// Mode 2 & 3 (Duel / Challenger) =======================
int p1Score = 0;
int p2Score = 0;

// ── setup() ──────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(9600);
  randomSeed(millis());

  intializeKeypad();
  intializeKeypad2();
  initializeLEDs();
  setup_LCD_SCREEN();

  // blink sequence
  turnOnAll();
  _delay_ms(BlinkTime);
  turnOffAll();
  _delay_ms(BlinkTime);
  turnOnAll();
  _delay_ms(BlinkTime);
  turnOffAll();
  _delay_ms(2500);

  Serial.println(F("=== Game Start ===")); // 'F' to save up ram (flash memory)
  Serial.println(F("State 0: Menu")); // 'F' to save up ram (flash memory)
}

// ── loop() ───────────────────────────────────────────────────────────────────
void loop() {
  switch (currentState) { // switch cases to get mode 

    case 0:  // ── Menu ──────────────────────────────────────
      menuFunction(); // default starting mode 
      break;

    case 1:  // ── Solo Mode ─────────────────────────────────
      Serial.println(F("Entering Mode 1")); // using serial print for debuging during simulation
      
      // Resets variables each time mode 1 is entered
      pass = 0;
      fail = 0;
      totalTime = 0;
      difficulty_level = DIFFICULTY_LEVEL;

      playmode1(); // play mode 1 function 
      // loop rounds until game ends then returns (goes back to menu)

      currentState = 0; // menu staten
      Serial.println(F("Mode 1 finished"));  // using serial print for debuging during simulation
      break; // breaks and returns to menu (break -> breaks the first loop it finds ;; return -> breaks the function)

    case 2:  // ── Duel Mode ─────────────────────────────────
      Serial.println(F("Entering Mode 2")); // using serial print for debuging during simulation

      // Resets variables each time mode 2 is entered
      p1Score = 0;
      p2Score = 0;

      
      playmode2(); // play mode 2 function 
      // loop rounds until game ends then returns (goes back to menu)

      currentState = 0; // menu state
      Serial.println(F("Mode 2 finished")); // using serial print for debuging during simulation
      break; // breaks and returns to menu (break -> breaks the first loop it finds ;; return -> breaks the function)

    case 3:  // ── Challenger Mode ────────────────────────────
      Serial.println(F("Entering Mode")); // using serial print for debuging during simulation

      // Resets variables each time mode 3 is entered
      p1Score = 0;
      p2Score = 0;

      runChallengerMode(); // play mode 3 function 
      // loop rounds until game ends then returns (goes back to menu)

      currentState = 0; // menu state
      Serial.println(F("Mode 3 finished")); // using serial print for debuging during simulation
      break; // breaks and returns to menu (break -> breaks the first loop it finds ;; return -> breaks the function)

    default: // does nothing but if any other buttons are pressed instead of the three buttons it will return to the menu
      Serial.println(F(" Unknown state, resetting to menu")); // using serial print for debuging during simulation
      currentState = 0; // menu state
      break; //returns to menu
  }
}
