// ============================================================
//  the extern below lets every other file see it automatically
// ============================================================

// Variables checked from the main file
extern int pass;
extern int fail;
extern int p1Score;
extern int p2Score;

// ── Initialise the display ────────────────────────────────────────────────────
void setup_LCD_SCREEN() {
  lcd.init();
  lcd.backlight(); // only used in hardware and not simulation
  lcd.setCursor(0, 0);
  lcd.print("EL3AB YA MA3ALIM");
  _delay_ms(1000);
  lcd.clear();

  //  scores 
  lcd.setCursor(0, 0);
  lcd.print("P1:");
  lcd.setCursor(10, 0);
  lcd.print("P2:");
}

// ── Update P1 and P2 score digits ─────────────────────────────────
void updateScores() {
  lcd.setCursor(3, 0);
  lcd.print(p1Score);
  lcd.print(" ");  
  lcd.backlight();
  lcd.setCursor(13, 0);
  lcd.print(p2Score);
  lcd.print(" ");
}

// ── Print an arbitrary message on row 1 ──────────────────────────────────────
void displayRoundResult(const char* msg) {
  lcd.setCursor(0, 1);
  lcd.print("                    ");   // clear the rows
  lcd.setCursor(0, 1);
  lcd.print(msg);
  lcd.backlight();
}

// ── Show current round number on row 1 ───────────────────────────────────────
void displayRoundNumber(int round) {
  lcd.setCursor(0, 1);
  lcd.print("Round:              ");
  lcd.setCursor(7, 1);
  lcd.print(round);
  lcd.backlight();
}

// ── Final game-over screen ────────────────────────────────────────────────────
void displayGameOver() {
  lcd.clear();
// lcd.backlight();
  lcd.setCursor(0, 0);
  if (p1Score > p2Score) {
    lcd.print("P1 Wins the Game!");
  } else if (p2Score > p1Score) {
    lcd.print("P2 Wins the Game!");
  } else {
    lcd.print("It's a Draw!");
  }
  lcd.setCursor(0, 1);
  lcd.print("P1:");
  lcd.print(p1Score);
  lcd.print("  P2:");
  lcd.print(p2Score);
}

// ── Mode 1 end-screen (pass and fail summary) ───────────────────────────────────
void loop_LCD_SCREEN_mode1() {
  lcd.clear();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Pass:");
  lcd.print(pass);
  lcd.setCursor(0, 1);
  lcd.print("Fail:");
  lcd.print(fail);
  lcd.setCursor(7,0);
  lcd.print("Avg Time:");
  lcd.setCursor(7,1);
  lcd.print((float)(totalTime / pass) / 1000.0);
  _delay_ms(4000);
  lcd.clear();
  lcd.setCursor(2,0);
  lcd.print("Mode 1 Ended");
}
