// PLAYER 1
#define BTN_ARRAY_ONE {2, 3, 4, 5} //From port B pins number (2, 3, 4, 5) 
#define BTN_DDR   DDRD
#define BTN_PORT  PORTD
#define BTN_PIN   PIND

// PLAYER 2
#define BTN_ARRAY_TWO {0, 1, 2, 3} //From port D pins number (8, 9, 10, 11)
#define BTN_2_DDR   DDRB
#define BTN_2_PORT  PORTB
#define BTN_2_PIN   PINB 
#define NUM_OF_BTNS 8


//LEDS 
#define LED_ARRAY {0, 1, 2, 3}   // A0 to A3
#define LED_DDR   DDRC
#define LED_PORT  PORTC
#define LED_PIN   PINC
#define NUM_OF_LEDS 4 
