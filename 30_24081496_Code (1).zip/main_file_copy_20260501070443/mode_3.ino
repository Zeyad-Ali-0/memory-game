// ============================================================
//  mode_3.ino  —  Challenger
// ============================================================

#include "hardware.h"
#include "config2.h"

// variables from the main file
extern int p1Score;
extern int p2Score;
extern bool willExit;

static int secretSequence[20];  // Sequence set by the challenger each round (sized for max difficulty)

// ──  read player's sequance ──────────────────────────
static int getActivePlayerButton(int playerNum) {
  if (playerNum == 1) {                            // player num one is playing 
    int btns[] = BTN_ARRAY_ONE;
    for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {
      if (!(BTN_PIN & (1 << btns[i]))) return i;   // return btn pressed
    }
  } else {
    int btns[] = BTN_ARRAY_TWO;                    // player num two is playing 
    for (int i = 0; i < NUM_OF_BTNS_PER_PLAYER; i++) {
      if (!(BTN_2_PIN & (1 << btns[i]))) return i; // return btn pressed
    }
  }
  return -1;                                       // no one pressed 
}

static void waitForPlayerRelease(int playerNum) {    // debounce 
  while (getActivePlayerButton(playerNum) != -1) {  
    _delay_ms(10);
  }
}

// ── Challenger enters the secret sequence ─────────────────────────────────────
static void enterSequence(int playerNum, int difficulty_level) {
  Serial.print(F(" Player "));
  Serial.print(playerNum);
  Serial.println(F(" is setting the sequence  "));
  displayRoundResult(playerNum == 1 ? "P1: Set Seq" : "P2: Set Seq");

  for (int i = 0; i < difficulty_level; i++) {      // repeats until full sequence is inputed 
    int btn = -1;
    while (btn == -1) {
      // P1 uses getButtonPressed() so the long-press exit fires naturally
      btn = (playerNum == 1) ? getButtonPressed() : getActivePlayerButton(playerNum);
      if (willExit) return;                         // exit mid-sequence if long press triggered
    }
    secretSequence[i] = btn;
    Serial.print(F("Step "));
    Serial.print(i + 1);
    Serial.print(F(": btn "));
    Serial.println(btn);

    // light up the LED for the pressed button
    LED_PORT |= (1 << btn);
    _delay_ms(300);
    turnOffAll();
    waitForPlayerRelease(playerNum);                // debounce 
  }
}

// ── Defender tries to replicate the sequence ──────────────────────────────────
static bool replicateSequence(int playerNum, int difficulty_level) {
  Serial.print(F(" Player "));
  Serial.print(playerNum);
  Serial.println(F(" attempting replication  "));
  displayRoundResult(playerNum == 1 ? "P1: Repeat!" : "P2: Repeat!");

  unsigned long startTime = millis();

  for (int i = 0; i < difficulty_level; i++) {      // sequanece replication loop
    int btn = -1;
    while (btn == -1) {
      if (millis() - startTime >= ROUND_TIMEOUT) {
        Serial.println(F("Result: TIMEOUT"));
        return false;
      }
      // P1 uses getButtonPressed() so the long-press exit fires naturally
      btn = (playerNum == 1) ? getButtonPressed() : getActivePlayerButton(playerNum);
      if (willExit) return false;                   // exit mid-replication if long press triggered
    }

    LED_PORT |= (1 << btn);                         // displays btn pressed 
    _delay_ms(200);
    turnOffAll();

    if (btn != secretSequence[i]) {
      Serial.print(F("Result: WRONG (Pressed "));
      Serial.print(btn);
      Serial.print(F(", Expected "));
      Serial.print(secretSequence[i]);
      Serial.println(F(")"));
      return false;                               // ends loop too
    }
    waitForPlayerRelease(playerNum);
  }

  Serial.println(F("Result: SUCCESS"));
  return true;                                    // sequance is correct 
}

// ── Main Challenger-mode entry point ─────────────────────────────────────────
void runChallengerMode() {
  int rounds = 0;
  bool p1IsChallenger = true;
  int difficulty_level = DIFFICULTY_LEVEL;  // starts at default, increases each successful round

  Serial.println(F("=== CHALLENGER MODE START ==="));
  updateScores();

  while (rounds < NUM_OF_ITERATIONS) {
    if (willExit) return;

    Serial.print(F("\n--- ROUND "));
    Serial.print(rounds + 1);
    Serial.print(F(" | DIFFICULTY: "));
    Serial.print(difficulty_level);
    Serial.println(F(" ---"));

    int challenger = p1IsChallenger ? 1 : 2;
    int defender = p1IsChallenger ? 2 : 1;

    enterSequence(challenger, difficulty_level);    // challenger enters sequence
    if (willExit) return;

    // prints the locked sequance
    Serial.print(F("Sequence Locked: "));
    for (int i = 0; i < difficulty_level; i++) {
      Serial.print(secretSequence[i]);
      Serial.print(' ');
    }
    Serial.println();

    // Step 2: flash sequence so defender can watch
    displayRoundResult("Watch!");
    _delay_ms(800);
    for (int i = 0; i < difficulty_level; i++) {
      LED_PORT |= (1 << secretSequence[i]);
      _delay_ms(BlinkTime);
      turnOffAll();
      _delay_ms(200);
    }

    // Step 3: defender tries to replicate
    bool defenderSucceeded = replicateSequence(defender, difficulty_level);
    if (defenderSucceeded) {
      if (defender == 1) p1Score++;
      else p2Score++;
      displayRoundResult("Success! +1");
      difficulty_level++;   // increase difficulty on defender success
      Serial.print(F("Difficulty increased to: "));
      Serial.println(difficulty_level);
    } else {
      displayRoundResult("Fail! Prove it!");
      Serial.println(F("Defender failed. Challenger must prove sequence."));
      _delay_ms(1000);

      if (replicateSequence(challenger, difficulty_level)) {
        if (challenger == 1) p1Score++;
        else p2Score++;
        displayRoundResult("Proved! +1");
        // difficulty stays the same — challenger proved it but defender failed
      } else {
        Serial.println(F("Challenger failed own proof! No points."));
        displayRoundResult("Liar! 0 pts");
        difficulty_level = DIFFICULTY_LEVEL;  // reset difficulty on failed proof (same logic as mode 1/2)
        Serial.print(F("Difficulty reset to: "));
        Serial.println(difficulty_level);
      }
    }

    updateScores();
    Serial.print(F("CURRENT SCORE of P1: "));
    Serial.print(p1Score);
    Serial.print(F(" | P2: "));
    Serial.println(p2Score);

    p1IsChallenger = !p1IsChallenger;
    rounds++;
    _delay_ms(1500);
  }

  Serial.println(F("=== CHALLENGER MODE OVER ==="));
  Serial.print(F("Final - P1: "));
  Serial.print(p1Score);
  Serial.print(F(" | P2: "));
  Serial.println(p2Score);

  displayGameOver();
  delay(3000);
  // Returns to loop(), currentState resets to 0 (menu)
}
